@extends('layouts.app')

@section('content')
    <div class="flex items-center justify-center min-h-screen bg-gray-100">
        <div class="text-center max-w-lg p-8 bg-white shadow-lg rounded-lg border border-gray-300">
            <h1 class="text-4xl font-bold text-gray-800 mb-4 leading-tight">
                Welcome to <span class="text-blue-600">Smart Healthcare Reminder</span>
            </h1>
            <p class="text-lg text-gray-600 mb-6">
                Manage your health effortlessly with medication reminders.
            </p>
            <a href="{{ route('medications.index') }}" 
               class="inline-block bg-blue-600 text-white py-3 px-8 rounded-lg text-lg font-semibold shadow-md hover:bg-blue-700 hover:shadow-lg transition-transform transform hover:scale-105">
                Get Started
            </a>
        </div>
    </div>
@endsection
