@extends('layouts.app')

@section('content')
    <h2 class="text-2xl font-bold mb-4">Edit Medication</h2>

    <form action="{{ route('medications.update', $medication) }}" method="POST" class="bg-white shadow-md p-6 rounded-lg">
        @csrf
        @method('PUT')

        <div class="mb-4">
            <label for="name" class="block text-gray-700">Medication Name</label>
            <input type="text" id="name" name="name" value="{{ old('name', $medication->name) }}" class="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            @error('name')
                <p class="text-red-500 text-sm">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="dosage" class="block text-gray-700">Dosage</label>
            <input type="text" id="dosage" name="dosage" value="{{ old('dosage', $medication->dosage) }}" class="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            @error('dosage')
                <p class="text-red-500 text-sm">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="frequency" class="block text-gray-700">Frequency</label>
            <input type="text" id="frequency" name="frequency" value="{{ old('frequency', $medication->frequency) }}" class="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            @error('frequency')
                <p class="text-red-500 text-sm">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="start_date" class="block text-gray-700">Start Date</label>
            <input type="date" id="start_date" name="start_date" value="{{ old('start_date', $medication->start_date) }}" class="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            @error('start_date')
                <p class="text-red-500 text-sm">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="end_date" class="block text-gray-700">End Date</label>
            <input type="date" id="end_date" name="end_date" value="{{ old('end_date', $medication->end_date) }}" class="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            @error('end_date')
                <p class="text-red-500 text-sm">{{ $message }}</p>
            @enderror
        </div>

        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">Update Medication</button>
    </form>
@endsection
