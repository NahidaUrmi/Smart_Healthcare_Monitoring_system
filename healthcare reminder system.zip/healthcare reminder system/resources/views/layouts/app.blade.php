<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Healthcare Reminder System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- TailwindCSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

<!-- AlpineJS for interactivity -->
<script src="https://cdn.jsdelivr.net/npm/alpinejs@2.8.2/dist/alpine.min.js" defer></script>
    @vite('resources/css/app.css')
</head>
<body class="bg-gray-50 font-inter antialiased">

    <!-- Navbar -->
<nav class="bg-white shadow-lg py-4">
    <div class="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <!-- Logo -->
        <a href="/" class="text-2xl font-bold text-gray-800 hover:text-blue-600 transition-colors">
            Smart Healthcare Reminder System
        </a>
        <!-- Navigation Links -->
        <div class="space-x-6 text-lg">
            <a href="{{ route('medications.index') }}" class="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Medications
            </a>
            <a href="{{ route('welcome') }}" class="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Home
            </a>
            @auth
            <a href="{{ route('logout') }}" class="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Logout
            </a>
            @else
            <a href="{{ route('login') }}" class="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Login
            </a>
            <a href="{{ route('register') }}" class="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                Register
            </a>
            @endauth
        </div>
    </div>
</nav>


<!-- Main Content -->
<main class="py-12 bg-gray-50">
    <div class="max-w-7xl mx-auto px-6 lg:px-8">
        @yield('content')
    </div>
</main>

<!-- Footer -->
<footer class="bg-gray-800 py-6">
    <div class="max-w-7xl mx-auto px-6 lg:px-8 text-center">
        <p class="text-sm text-gray-400">
            &copy; {{ date('Y') }} <span class="text-gray-300 font-medium">Healthcare Reminder System</span>. All rights reserved.
        </p>
    </div>
</footer>
</body>
</html>

