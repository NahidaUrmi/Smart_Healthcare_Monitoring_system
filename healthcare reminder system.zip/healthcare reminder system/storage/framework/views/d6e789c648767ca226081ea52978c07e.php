<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Smart Healthcare Reminder</h1>
        <p class="text-xl text-gray-600 mb-6">Manage your health easily with medication and appointment reminders.</p>
        <a href="<?php echo e(route('medications.index')); ?>" class="bg-indigo-600 text-white py-2 px-6 rounded-md text-lg font-semibold hover:bg-indigo-700 transition-colors">
            Get Started
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Herd\project\resources\views/welcome.blade.php ENDPATH**/ ?>