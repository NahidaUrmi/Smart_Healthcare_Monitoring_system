<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Medication;
use App\Models\User;
use Illuminate\Support\Facades\Notification;
use App\Notifications\MedicationReminderNotification;

class MedicationReminder extends Command
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'medication:reminder';

    /**
     * The console command description.
     */
    protected $description = 'Send reminders to users for their medications';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        // Get all medications where remaining doses are greater than 0 
        // and the next reminder time is due.
        $medications = Medication::where('remaining_doses', '>', 0)
    ->where('next_reminder_time', '<=', now())
    ->get();


        foreach ($medications as $medication) {
            // Get the user who owns this medication
            $user = $medication->user;

            // Send the reminder notification to the user
            Notification::send($user, new MedicationReminderNotification($medication));

            // Update the next reminder time (for example, every 6 hours)
            $medication->next_reminder_time = now()->addHours($medication->frequency); 
            $medication->save();
        }

        $this->info('Medication reminders sent successfully!');
    }
}
